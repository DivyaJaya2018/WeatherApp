//
//  ForecastModel.swift
//  Weather
//
//  Created by divyajayaseelan on 9/13/24.
//

import Foundation

struct Weather: Codable {
    
    let description: String
    let icon: String
    var iconURL: URL? {
        return URL(string: "https://openweathermap.org/img/wn/\(icon)@2x.png")
    }
}

struct ForecastModel: Codable {
        
        var weather: [Weather]
        let main: Main
        let name: String
                
        struct Main: Codable {
            let temp: Double
            var temperature: String {
                return String(format: "%.1f", temp)
            }
        }
        
        var cityName: String {
            return name
        }
}
