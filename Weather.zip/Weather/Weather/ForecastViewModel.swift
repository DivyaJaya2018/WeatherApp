//
//  ForecastViewModel.swift
//  Weather
//
//  Created by divyajayaseelan on 9/14/24.
//

import Foundation
import CoreLocation

enum APIError: Error {
   case error(_ errorString: String)
}

class ForecastViewModel: NSObject, ObservableObject {
    
      // MARK: - Published Properties
       @Published var forecast: ForecastModel?
       @Published var error: Error?
       @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined

       // MARK: - Constants
       private let apiKey = "040623cc9e2231e2b641512390b08cbe"
       private let weatherURL = "https://api.openweathermap.org/data/2.5/weather?"
       
       // MARK: - Private Properties
       private let locationManager = CLLocationManager()
       private let defaults = UserDefaults.standard

      // MARK: - Initialization
       override init() {
         super.init()
                locationManager.delegate = self
                locationManager.requestWhenInUseAuthorization()
       }
    
       // MARK: - Public Methods
       func fetchWeather(for city: String) {
           
           CLGeocoder().geocodeAddressString(city) { [self] (placemarks, error) in
                if let error = error {
                    print(error.localizedDescription)
                }
                if let lat = placemarks?.first?.location?.coordinate.latitude,
                   let lon = placemarks?.first?.location?.coordinate.longitude {
                    
                    let urlString = "\(self.weatherURL)lat=\(lat)&lon=\(lon)&exclude=current,minutely,hourly,alerts&appid=\(apiKey)"
                    
                    
                    guard let url = URL(string: urlString) else {
                        return
                    }
                    URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                        DispatchQueue.main.async {
                            if let data = data {
                                self?.parseWeather(data: data)
                                self?.defaults.set(city, forKey: "lastSearchedCity")
                            } else if let error = error {
                                self?.error = error
                            }
                        }
                    }.resume()
                }
            }
        }
    
        // MARK: - Private Methods
        private func parseWeather(data: Data) {
                let decoder = JSONDecoder()
                do {
                    let forecastResponse = try decoder.decode(ForecastModel.self, from: data)
                    DispatchQueue.main.async {
                        self.forecast = forecastResponse
                    }
                } catch {
                    self.error = error
                }
        }
        func fetchWeatherForCurrentLocation() {
              guard CLLocationManager.locationServicesEnabled() else { return }
              locationManager.requestLocation()
          }
      
        func loadLastCity() {
              if let city = defaults.string(forKey: "lastSearchedCity") {
                  fetchWeather(for: city)
              }
        }
      
}
extension ForecastViewModel: CLLocationManagerDelegate {
    // MARK: - CLLocationManagerDelegate Methods
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            fetchWeather(for: "\(location.coordinate.latitude),\(location.coordinate.longitude)")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        self.error = error
    }
}

