//
//  ContentView.swift
//  Weather
//
//  Created by divyajayaseelan on 9/13/24.
//

import SwiftUI
import CoreLocation

struct ContentView: View {
    // MARK: - State Properties
    @StateObject var viewModel = ForecastViewModel()
    @State private var location: String = ""
    @State private var showLocationPermissionAlert = false

    // MARK: - Body
    var body: some View {
        
        NavigationView {
            VStack {
                HStack {
                    TextField("Enter Location", text: $location)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button {
                        viewModel.fetchWeather(for: location)
                    } label: {
                        Image(systemName: "magnifyingglass.circle.fill")
                            .font(.title3)
                    }
                }
               if let weather = viewModel.forecast?.weather {
                    VStack {
                            Text(viewModel.forecast!.cityName)
                            .font(.largeTitle)
                            .padding()
                        
                        if let iconURL = weather.first?.iconURL {
                            AsyncImage(url: iconURL)
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                        }
                        if let temp = viewModel.forecast?.main.temp {
                            Text("Temperature: \(temp)°F")
                        }
                        if let description = weather.first?.description {
                            Text("Weather: \(description)")
                        }
                    }
                } else if let error = viewModel.error {
                        Text("Error: \(error.localizedDescription)")
                            .foregroundColor(.red)
                }
                Spacer()
            }
            .padding(.horizontal)
            .navigationTitle("Forecast Weather")
            .onAppear {
                viewModel.loadLastCity()
            }
            .onChange(of: viewModel.authorizationStatus) { status in
                if status == .denied {
                    showLocationPermissionAlert = true
                }
            }
        }
        // MARK: - Alerts
        .alert(isPresented: $showLocationPermissionAlert) {
                    Alert(title: Text("Location Permission"),
                          message: Text("Please enable location services for the app."),
                          dismissButton: .default(Text("OK")))
        }
    }
}

#Preview {
    ContentView()
}
