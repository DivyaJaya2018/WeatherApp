//
//  ForecastViewModelTests.swift
//  WeatherTests
//
//  Created by divyajayaseelan on 9/14/24.
//

import XCTest
@testable import Weather

final class ForecastViewModelTests: XCTestCase {
    
    var viewModel: ForecastViewModel!

    override func setUp() {
        super.setUp()
        viewModel = ForecastViewModel()
    }

    override func tearDown() {
        viewModel = nil
        super.tearDown()
    }

    func testFetchWeatherForCity() {
            let expectation = self.expectation(description: "Fetch weather")
            
            viewModel.fetchWeather(for: "San Francisco")
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                XCTAssertNotNil(self.viewModel.forecast, "Weather data should not be nil")
                XCTAssertNil(self.viewModel.error, "Error should be nil")
                XCTAssertEqual(self.viewModel.forecast?.cityName, "San Francisco", "City name should match")
                expectation.fulfill()
            }
            
            waitForExpectations(timeout: 3, handler: nil)
        }

    func testFetchWeatherForInvalidCity() {
            let expectation = self.expectation(description: "Fetch weather")
            
            viewModel.fetchWeather(for: "InvalidCityName")
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                XCTAssertNil(self.viewModel.forecast, "Weather data should be nil")
                XCTAssertNotNil(self.viewModel.error, "Error should not be nil")
                expectation.fulfill()
            }
            
            waitForExpectations(timeout: 3, handler: nil)
    }
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
